# Backend API
FastAPI service. It runs in demo mode unless `MODEL_PATH` points to compatible YOLO weights. Endpoints: `/health`, `/docs`, and `POST /predict` with multipart field `file`. Configure CORS to the exact frontend origin for deployment.
